import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-test',
  templateUrl: './test.component.html',
  styleUrls: ['./test.component.css']
})
export class TestComponent implements OnInit {

  movieTitle:string = localStorage.getItem('movie.title');
   screen: string = localStorage.getItem('movie.day');
    time: string = JSON.parse(localStorage.getItem('movie.time'));
    nooftickets: number = JSON.parse(localStorage.getItem('numberoftickets'));
    total: number = JSON.parse(localStorage.getItem('totalcost'));
total1=this.total+0.5;
seats:string = localStorage.getItem('seats');
 constructor() { }

  ngOnInit() {
  }

}
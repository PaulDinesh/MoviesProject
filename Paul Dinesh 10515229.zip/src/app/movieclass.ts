//<!--Paul Dinesh 10515229-->
export class movieclass {

  title: string;
  year: number;
  director: string;
  genre:string;
  notes:string;
  cast:string;
  runningTimes: any;

}